﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prog6221_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //creating a list that uses the recipe class as an object
        public List<Recipe> recipes = new List<Recipe>();

        public double TotalCalories { get; private set; } //creatin getters and setters

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try//using try catch to handle any user error
            {
                ListViewItem listViewItem = new ListViewItem();
                //creating local variables
                double qty, calories;
                string ingredientName, unitOfMeasurement, foodgroup, recipeName;

                recipeName = txtBoxRecipeName.Text;
                ingredientName = txtBoxIngredientName.Text;
                unitOfMeasurement = txtBoxUnit.Text;
                foodgroup = txtBoxFoodGroup.Text;
                qty = Convert.ToDouble(txtBoxQty.Text);
                calories = Convert.ToDouble(txtBoxCalories.Text);

                //Sorting in alphabetical order
                recipes = recipes.OrderBy(x => x.IngredientName).ToList();
                //Displaying in the listbox
                lstDisplayRecipe.Items.Add("Recipe Name: " + recipeName);
                lstDisplayRecipe.Items.Add("\nIngredient Name: " + ingredientName);
                lstDisplayRecipe.Items.Add("\nFood Group: " + foodgroup);
                lstDisplayRecipe.Items.Add("\nQuantity: " + qty);
                lstDisplayRecipe.Items.Add("\nUnit of Measurements: " + unitOfMeasurement);
                lstDisplayRecipe.Items.Add("\nCalories: " + calories);

                //an alert to let the user know if the calories is more than 300
                TotalCalories = recipes.Sum(x => x.Calories);

                if (calories > 300)
                {
                    MessageBox.Show("WARNING: The total calories of the recipe exceed 300!");
                }

                txtBoxRecipeName.Clear();
                txtBoxIngredientName.Clear();
                txtBoxQty.Clear();
                txtBoxCalories.Clear();
                txtBoxUnit.Clear();
                txtBoxFoodGroup.Clear();

            }
            catch
            {
                MessageBox.Show("Enter values !!!");
            }

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lstDisplayRecipe.Items.Clear();
            MessageBox.Show("Recipe has been cleared Successfully");
        }


        public void AddItems(string item)
        {
            lstDisplayRecipe.Items.Add(item);
        }

        private void btnSteps_Click(object sender, RoutedEventArgs e)
        {
            Steps steps = new Steps();
            steps.ShowDialog();
        }

        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            //using if statement to check which option is selected
            if (radioBtnScale0_5.IsChecked == true)
            {
                double scaleFactor = 0.5;
                Scaling(scaleFactor);
            }
            else if (radioBtnScale2.IsChecked == true)
            {
                double scaleFactor = 2;
                Scaling(scaleFactor);
            }
            else if (radioBtnScale3.IsChecked == true)
            {
                double scaleFactor = 3;
                Scaling(scaleFactor);
            }
            else
            {
                // No option is selected
                MessageBox.Show("Please select a scaling amount");
            }

        }

        private void Scaling(double scaleFactor)
        {
            for (int i = 0; i < lstDisplayRecipe.Items.Count; i++)
            {
                if (lstDisplayRecipe.Items[i] is string)
                {
                    string text = lstDisplayRecipe.Items[i] as string;
                    if (text.StartsWith("Quantity: "))
                    {
                        string qtyText = text.Substring("Quantity: ".Length);
                        if (double.TryParse(qtyText, out double qty))
                        {
                            double scaledQty = qty * scaleFactor;
                            text = "\nQuantity: " + scaledQty;
                            lstDisplayRecipe.Items[i] = text;
                        }
                    }
                }
            }
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Filter filter = new Filter();
                bool? result = filter.ShowDialog();

                if (result == true)
                {
                    // Get the filter criteria from the FilterWindow
                    string filterIngredient = filter.IngredientName;
                    string filterFoodGroup = filter.FoodGroups;
                    double filterCalories = filter.Calories;

                    lstDisplayRecipe.Items.Clear();

                    foreach (var item in recipes)
                    {
                        string text = item.ToString();
                        bool shouldDisplay = true;

                        if (!string.IsNullOrEmpty(filterIngredient))
                        {
                            if (!text.Contains(filterIngredient))
                            {
                                shouldDisplay = false;
                            }
                        }

                        if (!string.IsNullOrEmpty(filterFoodGroup))
                        {
                            if (!text.Contains("\nFood Group: " + filterFoodGroup))
                            {
                                shouldDisplay = false;
                            }
                        }

                        if (filterCalories < double.MaxValue)
                        {
                            if (text.Contains("\nCalories: "))
                            {
                                string caloriesText = text.Substring(text.IndexOf("\nCalories: ") + "\nCalories: ".Length);
                                if (double.TryParse(caloriesText, out double calories))
                                {
                                    if (calories > filterCalories)
                                    {
                                        shouldDisplay = false;
                                    }
                                }
                            }
                        }

                        if (shouldDisplay)
                        {
                            lstDisplayRecipe.Items.Add(item);
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Enter correct values");
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); //close the window
        }

    }
}
